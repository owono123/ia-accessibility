package com.monia.app;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import java.util.Random;

public class MyAccessibilityService extends AccessibilityService {
    private Random random = new Random();
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_ALL_MASK;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        setServiceInfo(info);
        handler.postDelayed(this::explore, 2000);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override
    public void onInterrupt() {}

    private void explore() {
        int x = 300 + random.nextInt(400);
        int y = 400 + random.nextInt(400);
        moveGaze(x, y);
        handler.postDelayed(this::explore, 2000 + random.nextInt(1500));
    }

    private void moveGaze(int x, int y) {
        Path path = new Path();
        path.moveTo(x - 20 + random.nextInt(40), y - 20 + random.nextInt(40));
        path.quadTo(x + random.nextInt(20) - 10, y + random.nextInt(20) - 10, x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 500 + random.nextInt(300)));
        dispatchGesture(builder.build(), null, null);
    }
}
